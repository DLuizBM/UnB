#ifdef __cplusplus
extern "C"{
    #endif
    extern int verifica_convexo(double x[], double y[]);
	extern double calcula_area(double x[], double y[]);
#ifdef __cplusplus


}
#endif
