#ifdef __cplusplus
extern "C"{
    #endif
    extern void read_in(double x[], double y[]);
    extern void exibir(double x[], double y[]);
#ifdef __cplusplus


}
#endif
