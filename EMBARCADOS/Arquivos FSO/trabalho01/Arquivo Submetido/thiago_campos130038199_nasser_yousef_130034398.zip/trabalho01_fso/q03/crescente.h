// Arquivo bib_arqs.hpp: Contém as definições dos protótipos das funções

#ifdef __cplusplus
extern "C"{
    #endif
    extern void crescente(int v[], int total);
#ifdef __cplusplus


}
#endif
