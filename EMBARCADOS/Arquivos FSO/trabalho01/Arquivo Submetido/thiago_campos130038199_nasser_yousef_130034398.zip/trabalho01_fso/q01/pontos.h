//define os pontos no plano cartesiano
#ifndef PONTOS_H
#define PONTOS_H

typedef struct pontos
{
	double x[4];
	double y[4];
} PONTOS;
#endif
